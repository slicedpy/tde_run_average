# Title: TSHEET-REPORTENGINE.py
# Date: 22 JUNE 2018
# Contributors: Optum Care Practice Management; Charles E. Bezak; Tiffanee C. Lang
# Purpose: Automate the process of the monthly T-Sheet Payrool processing
#
# Requestor: Ingrid Patin
#
# Reoccurence:
# Monthly
#
# Source/Input:
# T-SHEETS Extraction (.csv)
#
# Destination/Output:
# Completed .XLS worksheet for payroll as desginated by the
# 'Ryan CALC constriants; PDF email delivery to be released in update.
#
# Estimated Time of Completion
# 40.0 HOURS
#-----------------------------------------------------------------------------

# Import needed packages()
#
# time : aligns the server(or host) clocking to create timestamps, etc
#
# csv: Allows the import of 'data' files--can be easily subbed for odbc
#
# os: Allows the manipulation of the window to fit the banners
#
# xlrd: Excel Reader--enables script to read from excel files
#
# xlsxwriter: Excel Wrister--enables script to write to excel files;
# note to self--there is a hybrid python package that can both read
# and write to Excel 2013+.
#
#
#
# Dependencies
# tsheets-YYYY-MM.csv - Extractions from T-SHEETS interface
#
# ryan_calc_template.xls - The overlay excel worksheet that needs
# data input into it with predetermined formulas.
#
#
#
# Global Variables()
#
#
# Classes()
#
#
#    
# Functions ()
#

import xlsxwriter
import xlrd
import calendar
import os
from datetime import date
import openpyxl as op
import time


def getTimeSheet(TSheetInput):
    hoursToLoad = op.load_workbook(TSheetInput)
    TimeEntries = []
    for each in hoursToLoad.sheetnames:
        shifts = []
        active_sheet = hoursToLoad[each]
        shifts.append(active_sheet.title)

        header_column = active_sheet['1']
        start_time_column,end_time_column,duration_column ='','',''


        for current_column in range(len(header_column)):
            current_label = header_column[current_column].value
            
            if current_label == 'local_start_time':
                start_time_column = header_column[current_column].column

                
            elif current_label == 'local_end_time':
                end_time_column = header_column[current_column].column

                
            elif current_label == 'hours':
                duration_column = header_column[current_column].column

        for row_iter in range(2,24):
            start_time = active_sheet[start_time_column+str(row_iter)]
            end_time = active_sheet[end_time_column+str(row_iter)]
            duration = active_sheet[duration_column+str(row_iter)]
            if start_time.value is not None:
                shifts.append(
                    [
                        str(active_sheet.title),
                        str(start_time.value),
                        str(end_time.value),
                        str(duration.value)
                        ]
                    )

        TimeEntries.append(shifts)

    return TimeEntries

timeSheetToComplete = op.load_workbook('timeSheet.xlsm',read_only=False,keep_vba=True)

for each in timeSheetToComplete.sheetnames:
    active_sheet = timeSheetToComplete[each]

    headerCell = active_sheet['AH']
    
    for i in headerCell:
        if i.value == 'T-Sheets Data Drop':
            timeCard = active_sheet['AI'+str(i.row+2):'AK42']

    for each in getTimeSheet('TSheets Data (April 2018).xlsx'):
        if each[0] == active_sheet.title:
            for y,bar in zip(each[1:],timeCard):
                bar[0].value = y[1]
                bar[1].value = y[2]
                bar[2].value = y[3]

timeSheetToComplete.save('timeSheet.xlsm')


##                
##                #print("adding "+str(y[1]) +"   |   "+str(y[2]) +"   |   "+str(y[3]))
##                time.sleep(2)
##                for bar in timeCard:
##                    print(bar)
####                    #print("adding "+str(y[1]) +"   |   "+str(y[2]) +"   |   "+str(y[3]))
####                    r1.value = y[1]
####                    r2.value = y[2]
####                    r3.value = y[3]
####            print("\n")
##    


##        line_date = str(each[0])
##        line_data = ""
##        if str(each[0]) == str(active_sheet.title):
##                headerCell = active_sheet['AH']
##                #for i in headerCell:
##                    #if i.value == 'T-Sheets Data Drop':
##                        #timeCard = active_sheet['AI'+str(i.row+2):'AK42']
##                        #for r1,r2,r3 in timeCard:
##
##                print(each[0])
##                for foo in each[1]:
##                    print(foo)
##




##
##cal = calendar.Calendar()
##
##def runSheets(year):
##    for month_num in range(1,13):
##        workbook = xlsxwriter.Workbook(str(year)+'_'+str(month_num).zfill(2)+'_output.xlsx')
##        for each in cal.itermonthdays(year,month_num):
##            if each !=0:
##                sheet_name = str(month_num).zfill(2)+'.'+str(each).zfill(2)
##                worksheet = workbook.add_worksheet(sheet_name)
##                worksheet.write('A1','foo-bar')
##    workbook.close()
##
##in_year = 2018
##try:
##    os.remove(str(in_year)+'_output.xlsx')
##    runSheets(in_year)
##except:
##    runSheets(in_year)
####
##my_date = date.today()
##print(my_date)
##print(calendar.day_name[my_date.weekday()])




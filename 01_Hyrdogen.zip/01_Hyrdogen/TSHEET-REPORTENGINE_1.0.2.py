# Project Hydrogen (#0001)
# Title: TSHEET-REPORTENGINE.py
# Date: 22 JUNE 2018
# Contributors: Optum Care Practice Management; Charles E. Bezak; Tiffanee C. Lang
# Purpose: Automate the process of the monthly T-Sheet Contract Compliance processing
# Beta Objective: UMC Contract Compliance
#
# Requestor: Ingrid Patin
#
# Reoccurence:
# Monthly
#
# Source/Input:
# T-SHEETS Extraction (.csv)
#
# Destination/Output:
# Completed .XLSM (Macro-Enabled) worksheet for payroll as desginated by the
# 'Ryan CALC constriants'.
#
#
# Further Development:
# Progress_flag switching
# PDF email delivery
# Local interfacing for hosting server
# Authorization, Authentiation
# Holidays
#
#
# Known Bugs, Issues and Fixes:
# Keep a look out for date formatting
#
#
# Estimated Time of Completion
# 40.0 HOURS
#-----------------------------------------------------------------------------

# Import needed packages()
#
# datetime : Used for formatting and evaluation of date fields/data types
# calendar : Used for iterating throught years, months, days, etc consistently
# os       : Allows the manipulation of the window to fit the banners
# openpyxl : Third-party Excel library to read/write from MS Excel
# time     : aligns the server(or host) clocking to create timestamps, etc
#
# Dependencies
# TSheets Data (Month Year).xlsx (Extractions from T-SHEETS interface, whole month)
# each day represented on each sheet.
#
# april - The overlay excel worksheet that needs
# data input into it with predetermined formulas.
#
#
#
# Global Variables()
#
#
# Classes()
#
#
#    
# Functions ()
#

from datetime import *
import calendar
import os
import openpyxl as op
import time

cal = calendar.Calendar()

def getTimeSheet(TSheetInput):
    time.sleep(1)
    print("Gettings Time Sheet(s)...")
    time.sleep(3)
    hoursToLoad = op.load_workbook(TSheetInput)
    TimeEntries = []
    
    for each in hoursToLoad.sheetnames:
        shifts = []
        active_sheet = hoursToLoad[each]
        shifts.append(active_sheet.title)

        header_column = active_sheet['1']
        start_time_column,end_time_column,duration_column ='','',''


        for current_column in range(len(header_column)):
            current_label = header_column[current_column].value
            
            if current_label == 'local_start_time':
                start_time_column = header_column[current_column].column

                
            elif current_label == 'local_end_time':
                end_time_column = header_column[current_column].column

                
            elif current_label == 'hours':
                duration_column = header_column[current_column].column

        for row_iter in range(2,32):
            start_time = active_sheet[start_time_column+str(row_iter)]
            end_time = active_sheet[end_time_column+str(row_iter)]
            duration = active_sheet[duration_column+str(row_iter)]
            if start_time.value is not None:
                shifts.append(
                    [
                        str(active_sheet.title),
                        str(start_time.value),
                        str(end_time.value),
                        str(duration.value)
                        ]
                    )

        TimeEntries.append(shifts)

    return TimeEntries

def CompletePayrollForm(PayrollWorkbook):
    timeSheetToComplete = op.load_workbook(PayrollWorkbook,read_only=False,keep_vba=True,guess_types=True)
    dataset = getTimeSheet('TSheets Data (April 2018).xlsx')
    print("Complete Payroll Form...")
    time.sleep(3)

    for each in timeSheetToComplete.sheetnames:
        #if progress_flag == True:
        #print(each)
        active_sheet = timeSheetToComplete[each]
        headerCell = active_sheet['AH']
            
        for i in headerCell:
            if i.value == 'T-Sheets Data Drop':
                #if progress_flag == True:
                # print(i.row)
                timeCard = active_sheet['AI'+str(i.row+2):'AK'+str(i.row+24)]
        
                for each in dataset:
                    #if progress_flag == True: print(each)
                    
                    if each[0] == active_sheet.title:
                        #if progress_flag == True:
                        print("NOW PROCESSING DATA FOR THE "+str(each[0])+" SHEET.")
                        input_data = each[1:]
                        for line,cell in zip(input_data,timeCard):
                            cell[2].number_format = '0.00'
                            
                            cell[0].value=datetime.strptime(line[1],"%Y-%m-%d %H:%M:%S")
                            cell[1].value=datetime.strptime(line[2],"%Y-%m-%d %H:%M:%S")
                            cell[2].value=float(line[3])

                        #if progress_flag == True:
                        #print(str(len(each[1:])) + " records add...supposedly.")
                    else:
                        continue
                        #print("Error Dummy...")

    timeSheetToComplete.save(PayrollWorkbook)
    User_Close = input("\n Task is complete. Please review files saved in the directory.")


def createDatedSheets(year,month_num):
    print('Creating Dated Sheets...')
    time.sleep(3)
    wb = op.load_workbook('april2018.xlsm',read_only=False,keep_vba=True)

    for each in cal.itermonthdays(year,month_num):
        if each !=0:
            sheet_name = str(month_num)+'.'+str(each).zfill(2)
            datetime_object = datetime.strptime(str(year)+'-'+str(month_num).zfill(2)+'-'+str(each).zfill(2), '%Y-%m-%d')
            if calendar.day_name[datetime_object.weekday()] == 'Sunday':
                active_sheet = wb['Sunday']
                target = wb.copy_worksheet(active_sheet)
                target.title = sheet_name
                target['B1'].value=datetime.strptime(str(month_num)+"/"+str(each)+"/"+str(year) + " 7:00:00 AM","%m/%d/%Y %H:%M:%S %p")
       
                
            elif calendar.day_name[datetime_object.weekday()] == 'Saturday':
                active_sheet = wb['Saturday']
                target = wb.copy_worksheet(active_sheet)
                target.title = sheet_name
                target['B1'].value=datetime.strptime(str(month_num)+"/"+str(each)+"/"+str(year) + " 7:00:00 AM","%m/%d/%Y %H:%M:%S %p")
              
                
            else:
                active_sheet = wb['Weekday']
                target = wb.copy_worksheet(active_sheet)
                target.title = sheet_name
                target['B1'].value=datetime.strptime(str(month_num)+"/"+str(each)+"/"+str(year) + " 7:00:00 AM","%m/%d/%Y %H:%M:%S %p")
         
                
    wb.save('april2018.xlsm')

if __name__ == "__main__":
    print("SCRIPT START TIME: "+datetime.strftime(datetime.now(),'%m/%d/%Y %H:%M:%S %p')+"\n")
    createDatedSheets(2018,4)
    CompletePayrollForm('april2018.xlsm')
    print("SCRIPT END TIME: "+datetime.strftime(datetime.now(),'%m/%d/%Y %H:%M:%S %p')+"\n")
